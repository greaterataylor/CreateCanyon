# Local demonstration source

A harmless static test fixture. The marketplace never executes uploaded code.
