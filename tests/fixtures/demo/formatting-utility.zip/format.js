/** Example source, not executed by the marketplace. */
export function title(value) { return String(value).trim(); }
