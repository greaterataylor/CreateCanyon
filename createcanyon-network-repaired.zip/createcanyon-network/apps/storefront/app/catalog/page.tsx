export {default} from '../page';
